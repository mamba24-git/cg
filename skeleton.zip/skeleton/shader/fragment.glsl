#version 120

varying vec3 v_position_wc;
varying vec3 v_normal_wc;

uniform vec3 u_light_position;
uniform vec3 u_light_ambient;
uniform vec3 u_light_diffuse;
uniform vec3 u_light_specular;

uniform vec3 u_obj_ambient;
uniform vec3 u_obj_diffuse;
uniform vec3 u_obj_specular;
uniform float u_obj_shininess;

uniform vec3 u_camera_position;

void main()
{
    // Normalization
    vec3 normal = normalize(v_normal_wc);
    // Direction to light (directional/point light)
    vec3 light_dir = normalize(u_light_position - v_position_wc);
    // Direction to camera (viewer)
    vec3 view_dir = normalize(u_camera_position - v_position_wc);

    // Ambient
    vec3 ambient = u_light_ambient * u_obj_ambient;

    // Diffuse
    float ndotl = max(dot(normal, light_dir), 0.0);
    vec3 diffuse = u_light_diffuse * u_obj_diffuse * ndotl;

    // Specular
    vec3 reflect_dir = reflect(-light_dir, normal);
    float spec = pow(max(dot(reflect_dir, view_dir), 0.0), u_obj_shininess);
    vec3 specular = u_light_specular * u_obj_specular * spec;

    // Sum
    vec3 color = ambient + diffuse + specular;

    gl_FragColor = vec4(color, 1.0);
}
