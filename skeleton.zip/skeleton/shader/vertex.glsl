#version 120

attribute vec3 a_position;
attribute vec3 a_normal;

uniform mat4 u_PVM;           // Projection * View * Model
uniform mat4 u_model_matrix;  // Model 행렬 (local → world)
uniform mat3 u_normal_matrix; // Model의 상단 3x3 역전치 (normal 변환용)

varying vec3 v_position_wc;   // world 좌표계의 위치
varying vec3 v_normal_wc;     // world 좌표계의 normal

void main()
{
    gl_Position = u_PVM * vec4(a_position, 1.0);
    v_position_wc = (u_model_matrix * vec4(a_position, 1.0)).xyz;
    v_normal_wc = normalize(u_normal_matrix * a_normal);
}